/* ===========================================================================
   TULYA — modules layer
   ---------------------------------------------------------------------------
   Material Passport · Engineering Evidence · Standards Knowledge Graph ·
   Analytics · Collaboration · Cross-CPSE Impact Simulator · Procurement
   Intelligence, plus the operational tables on the overview.

   Every one of these reads TULYA.materials — the single derived model built
   from the material records the console already ships. There is no second
   dataset and no page-local fixture.
   =========================================================================== */

/* ---------- shared vocabulary ------------------------------------------- */
const VERDICT_GLYPH = { IDENTICAL: '=', EQUIVALENT: '≈', CONDITIONAL: '~',
                        DIFFERENT: '≠', CONFLICT: '✕', UNRESOLVED: '?' };

const VERDICT_SHORT = { IDENTICAL: 'IDENTICAL', EQUIVALENT: 'EQUIVALENT',
  CONDITIONAL: 'CONDITIONAL', DIFFERENT: 'DIFFERENT', CONFLICT: 'CONFLICT', UNRESOLVED: 'UNRESOLVED' };

/* compact: the short label, for a table cell. The full wording stays on hover. */
function verdictBadge(key, withNext, compact) {
  const v = TULYA.VERDICTS[key]; if (!v) return '';
  const label = compact ? VERDICT_SHORT[key] : v.label;
  return `<span class="vb ${v.cls}" title="${v.label} \u2014 ${v.next}"><span class="g">${VERDICT_GLYPH[key]}</span>${label}</span>` +
         (withNext ? `<span class="vb-next">${v.next}</span>` : '');
}
const qty = n => Number(n || 0).toLocaleString('en-US');
const el = id => document.getElementById(id);
const clock = ts => new Date(ts * 1000).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

/* the trust model, as a process rail rather than six billboards */
function procRailHTML() {
  return [
    ['ai',   'Candidate',  'semantic retrieval proposes',   'The engine retrieves candidates on meaning and text. It never merges anything.'],
    ['ev',   'Evidence',   'attributes and standards read', 'Specifications are recovered from both descriptions and compared one by one.'],
    ['veto', 'Validation', 'conflicts block the merge',     'A specification known on both sides and disagreeing forces the score to zero.'],
    ['gov',  'Steward',    'a named person decides',        'Nothing maps until a steward signs it, and the decision carries their name.'],
    ['cnmc', 'CNMC',       'legacy codes retained',         'A Common National Material Code maps the legacy ERP codes; it does not replace them.'],
    ['',     'Audit',      'traceable and actionable',      'Every decision is appended to the audit log and becomes visible to procurement.']
  ].map(([cls, t, d, tip]) =>
    `<div class="s ${cls}" title="${tip}"><div class="t"><i></i>${t}</div><div class="d">${d}</div></div>`
  ).join('');
}

/* app-bar breadcrumb, driven by the panel the rail switches to */
const PAGE_MAP = {
  overview: ['Workspace', 'Overview'], challenge: ['Workspace', 'Test TULYA'],
  queue: ['Workspace', 'Review Queue'], auto: ['Workspace', 'Auto-Suggest'],
  passport: ['Material Intelligence', 'Material Passport'],
  analytics: ['Material Intelligence', 'Analytics'],
  simulator: ['Material Intelligence', 'Impact Simulator'],
  procurement: ['Operations', 'Procurement Intelligence'],
  collab: ['Operations', 'Collaboration'],
  groups: ['Governance', 'Golden Records'], vetoed: ['Governance', 'Hard-Key Vetoes'],
  standards: ['Governance', 'Standards Knowledge Graph'], audit: ['Governance', 'Audit Log'],
  performance: ['System', 'Performance'], search: ['System', 'Search']
};
function installChrome() {
  const base = switchPanel;
  switchPanel = function (name) {
    base(name);
    const p = PAGE_MAP[name] || ['Workspace', name];
    if (el('crumbGroup')) el('crumbGroup').textContent = p[0];
    if (el('crumbPage')) el('crumbPage').textContent = p[1];
  };
}

/* ---------- small table helpers ----------------------------------------- */
function tableHTML(cols, rows, opts) {
  opts = opts || {};
  if (!rows.length) return `<div class="empty">${opts.empty || 'Nothing to show.'}</div>`;
  return `<div class="twrap"><table><thead><tr>${
    cols.map(c => `<th${c.num ? ' class="num"' : ''}>${c.h}</th>`).join('')
  }</tr></thead><tbody>${rows.join('')}</tbody></table></div>` +
  (opts.foot ? `<div class="tfoot">${opts.foot}</div>` : '');
}
function showing(n, total, label) {
  return `<span class="count">Showing <b>${qty(n)}</b> of <b>${qty(total)}</b> ${label || 'rows'}</span>`;
}

/* ===========================================================================
   ENGINEERING EVIDENCE — a comparison table
   =========================================================================== */
function evidenceTableHTML(it) {
  const rows = TULYA.evidenceRows(it);
  const a = it.record_a, b = it.record_b;
  const mism = rows.filter(r => r.verdict === 'MISMATCH');
  const scope = rows.filter(r => r.verdict === 'REVIEW SCOPE');
  const agree = rows.filter(r => r.verdict === 'MATCH');

  const line = r => {
    const cls = r.verdict === 'MATCH' ? 'match' : r.verdict === 'MISMATCH' ? 'mismatch'
              : r.verdict === 'REVIEW SCOPE' ? 'scope' : 'unknown';
    const res = r.verdict === 'MATCH' ? '✓ MATCH' : r.verdict === 'MISMATCH' ? '✕ CONFLICT'
              : r.verdict === 'REVIEW SCOPE' ? 'REVIEW SCOPE' : 'NOT READABLE';
    const dim = v => v == null ? '<span style="color:var(--n-300)">—</span>' : esc(v);
    return `<div class="ev-line ${cls}">
      <div class="k">${esc(r.label)}${r.hard ? '<span class="hard">HARD KEY</span>' : ''}</div>
      <div class="val">${dim(r.a)}</div><div class="val">${dim(r.b)}</div>
      <div class="res">${res}</div></div>`;
  };

  let foot;
  if (mism.length) {
    foot = `<b>Hard specification conflict.</b> ${mism.map(r => esc(r.label) + ' reads ' + esc(r.a) +
      ' against ' + esc(r.b)).join('; ')}. A specification known on both sides and disagreeing forces the
      score to zero however similar the text is — the merge is refused, not averaged away.`;
  } else if (scope.length) {
    foot = `<b>Standards scope differs.</b> The attributes agree, but the records cite different
      designations. A scoped cross-reference is not an assertion of equivalence, so this routes to
      engineering review rather than straight to a steward.`;
  } else {
    foot = `<b>${agree.length} specification${agree.length === 1 ? '' : 's'} agree, none in conflict.</b>
      Attribute agreement is what supports this proposal; the text similarity on its own would not.`;
  }

  return `<div class="ev-table">
    <div class="ev-head">
      <div>Attribute</div>
      <div class="src">Record A<b>${esc(a.cpse)} · ${esc(a.legacy_code)}</b></div>
      <div class="src">Record B<b>${esc(b.cpse)} · ${esc(b.legacy_code)}</b></div>
      <div>Result</div>
    </div>
    ${rows.map(line).join('') || '<div class="ev-line unknown"><div class="k">specifications</div><div class="val" style="grid-column:2/5;color:var(--n-400)">No specification was readable on both sides.</div></div>'}
    <div class="ev-foot">${foot}</div>
  </div>
  <div class="notequal"><b>SIMILARITY ≠ EQUIVALENCE</b>
    <span>Text similarity is ${(it.cos * 100).toFixed(1)}% on this pair. The result column above decides
    whether it may be mapped — not the score.</span></div>`;
}

/* ===========================================================================
   OVERVIEW — operational tables
   =========================================================================== */
const ACTION_LABEL = { approve: 'Approved', reject: 'Rejected', unmerge: 'Split out',
                       conditional: 'Marked conditional', verify: 'Verification requested',
                       assign: 'Assignment', comment: 'Comment', engineering: 'Engineering review',
                       escalate: 'Escalated' };

function renderOverviewOps() {
  if (el('ovUpdated')) el('ovUpdated').textContent = new Date().toLocaleString('en-GB',
    { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });

  /* recent material decisions */
  const dec = STATE.audit.filter(r => ['approve', 'reject', 'unmerge', 'conditional'].includes(r.action));
  el('ovDecisions').innerHTML = tableHTML(
    [{ h: 'Material' }, { h: 'CPSE' }, { h: 'Decision' }, { h: 'Confidence', num: 1 },
     { h: 'Steward' }, { h: 'Time' }],
    dec.slice(0, 8).map(r => {
      const rec = RECORDS[r.record_a] || {};
      return `<tr><td>${esc((rec.description || '—').slice(0, 52))}</td>
        <td>${esc(rec.cpse || '—')}</td>
        <td><span class="pill ${['approve','reject','unmerge'].includes(r.action) ? r.action : 'review'}">${esc(ACTION_LABEL[r.action] || r.action)}</span></td>
        <td class="num mono">${r.score != null ? (r.score * 100).toFixed(1) + '%' : '—'}</td>
        <td>${esc(r.steward || '—')}</td>
        <td class="mono">${clock(r.ts)}</td></tr>`;
    }),
    { empty: 'No steward decisions recorded in this browser yet. Open the review queue to make one.',
      foot: dec.length ? showing(Math.min(8, dec.length), dec.length, 'decisions') +
        `<button class="jump" onclick="switchPanel('audit')">Full audit log</button>` : '' });

  /* cross-CPSE opportunities */
  const rows = TULYA.procurementRows().filter(r => r.material.cross_cpse).slice(0, 6);
  el('ovOpportunities').innerHTML = crossTable(rows, 'ovOpportunities');

  /* system activity */
  const act = STATE.audit.slice(0, 8);
  el('ovActivity').innerHTML = tableHTML(
    [{ h: 'Timestamp' }, { h: 'Event' }, { h: 'Records' }, { h: 'Actor' }],
    act.map(r => `<tr><td class="mono">${new Date(r.ts * 1000).toLocaleString('en-GB')}</td>
      <td>${esc(ACTION_LABEL[r.action] || r.action)}${r.detail ? ' <span style="color:var(--n-400)">— ' + esc(String(r.detail).slice(0, 70)) + '</span>' : ''}</td>
      <td class="mono">${r.record_a}${r.record_b != null ? ' ↔ ' + r.record_b : ''}</td>
      <td>${esc(r.steward || '—')}</td></tr>`),
    { empty: 'No system activity yet in this browser.' });
}

function crossTable(rows, tag) {
  return tableHTML(
    [{ h: 'Material' }, { h: 'CNMC' }, { h: 'CPSEs' }, { h: 'Stock', num: 1 },
     { h: 'Demand', num: 1 }, { h: 'Coverage' }, { h: 'Status' }, { h: '' }],
    rows.map(r => `<tr>
      <td>${esc(r.material.description.slice(0, 44))}<div class="site">${esc(r.material.category_label)}</div></td>
      <td class="mono">${esc(r.material.cnmc)}</td>
      <td class="mono">${esc(r.material.cpses.join(' '))}</td>
      <td class="num mono">${qty(r.available)}</td>
      <td class="num mono">${qty(r.required)}</td>
      <td><div class="cov-mini"><span class="t"><i class="${r.coverage >= 1 ? '' : 'part'}" style="width:${(r.coverage * 100).toFixed(0)}%"></i></span>
        <span class="mono">${(r.coverage * 100).toFixed(0)}%</span></div></td>
      <td><span class="sig ${SIGCLS[r.signal]}">${r.signal}</span></td>
      <td><div class="rowacts"><button onclick="gotoProcurement('${r.material.id}')">Open</button></div></td>
    </tr>`),
    { empty: 'No cross-CPSE opportunity in the current model.',
      foot: rows.length ? `<span class="count">Quantities <b>simulated</b></span>
        <button class="jump" onclick="switchPanel('procurement')">All procurement opportunities</button>` : '' });
}

/* ===========================================================================
   MATERIAL PASSPORT
   =========================================================================== */
let PASSPORT_ID = null, PASSPORT_FILTER = '';

function bestCaseFor(m) {
  if (!m.cases.length) return null;
  const order = { CONFLICT: 0, CONDITIONAL: 1, UNRESOLVED: 2, EQUIVALENT: 3, IDENTICAL: 4, DIFFERENT: 5 };
  return m.cases.slice().sort((x, y) =>
    order[TULYA.verdictOf(x).key] - order[TULYA.verdictOf(y).key] || y.score - x.score)[0];
}
function openPassport(matId) { PASSPORT_ID = matId; switchPanel('passport'); renderPassport(); }
function passportForRecord(rid) {
  const m = TULYA.byRecord[rid];
  if (m) openPassport(m.id); else toast('No material identity for that record');
}

function renderPassport() {
  const list = TULYA.materials;
  if (!PASSPORT_ID || !TULYA.byId[PASSPORT_ID]) PASSPORT_ID = (list[0] || {}).id;
  const q = PASSPORT_FILTER.toLowerCase();
  const shown = list.filter(x => !q || (x.description + ' ' + x.cnmc + ' ' + x.cpses.join(' ') + ' ' +
                 x.legacy_identities.map(l => l.legacy_code).join(' ')).toLowerCase().includes(q));

  if (el('ppCount')) el('ppCount').textContent = qty(list.length);
  el('ppListCount').innerHTML = showing(Math.min(60, shown.length), shown.length, 'materials') +
    (q ? ` <button class="jump" onclick="clearPassportFilter()">Clear</button>` : '');

  el('passportList').innerHTML = shown.slice(0, 60).map(x =>
    `<button class="r${x.id === PASSPORT_ID ? ' on' : ''}" onclick="openPassport('${x.id}')">
       <div class="d">${esc(x.description)}</div>
       <div class="m"><span>${x.records.length} legacy</span><span>${esc(x.cpses.join(' '))}</span></div>
     </button>`).join('') || '<div class="empty">No material matches that filter.</div>';

  const m = TULYA.byId[PASSPORT_ID];
  el('passportDetail').innerHTML = m ? passportHTML(m) : '<div class="empty">No material selected.</div>';
}
function clearPassportFilter() { PASSPORT_FILTER = ''; el('passportSearch').value = ''; renderPassport(); }

function passportHTML(m) {
  const c = bestCaseFor(m);
  const v = c ? TULYA.verdictOf(c) : { key: m.equivalence_status, reason: 'no candidate pair shipped for this record' };
  const fam = TULYA.STANDARDS[m.family] || { nodes: [], edges: [] };
  const approved = c && STATE.reviews[pkey(c.a, c.b)] && STATE.reviews[pkey(c.a, c.b)].action === 'approve';

  const analysis = c ? [
    ['Semantic similarity', (c.cos * 100).toFixed(1) + '%', 'measured'],
    ['Token similarity', (c.fuz * 100).toFixed(1) + '%', 'measured'],
    ['Attribute agreement', (c.explain.attributes || []).filter(a => a.verdict === 'MATCH').length + ' of ' +
                            (c.explain.attributes || []).length + ' readable', 'measured'],
    ['Fused score', (c.score * 100).toFixed(1) + '%', 'measured'],
    ['Engineering validation', v.key === 'CONFLICT' ? 'Refused — hard key conflict'
                              : (c.coverage >= 2 ? 'Passed' : 'Thin evidence — capped at review'), 'measured'],
    ['Standards relationship', fam.nodes.length ? (fam.nodes[0].verified ? 'Scoped cross-reference on file'
                              : 'Prototype — requires verification') : 'None on file', 'derived'],
    ['Conflict detection', v.key === 'CONFLICT' ? 'Conflict raised' : 'None', 'measured']
  ] : [];

  return `<div class="pp">
    <div class="pp-head">
      <div class="eyebrow">Material passport</div>
      <div class="t">${esc(m.description)}</div>
      <div class="row">
        <div class="f"><span class="k">CNMC</span><span class="v">${esc(m.cnmc)}</span></div>
        <div class="f"><span class="k">Status</span><span class="v">${verdictBadge(v.key)}</span></div>
        <div class="f"><span class="k">Category</span><span class="v">${esc(m.category_label)}</span></div>
        <div class="f"><span class="k">CPSEs</span><span class="v">${esc(m.cpses.join(' · '))}</span></div>
        <div class="f"><span class="k">Issuance</span><span class="v">${approved ? 'ISSUED' : 'PROPOSED'}</span></div>
      </div>
    </div>

    <div class="pp-grid">
      <div>
        <div class="kicker">Identity</div>
        <div class="attrgrid">
          <div class="k">Normalised description</div><div class="v" style="text-align:left">${esc(m.description)}</div>
          <div class="k">Material family</div><div class="v">${esc(m.family_name)}</div>
          <div class="k">Source records</div><div class="v">${m.records.length}</div>
          <div class="k">Plants</div><div class="v">${m.plants.length}</div>
        </div>

        <div class="kicker">Legacy codes <span class="prov">source records</span></div>
        ${m.legacy_identities.map(l => `<div class="idrow">
          <span><b>${esc(l.cpse)}</b></span>
          <span class="site">${esc(l.plant || '')}</span>
          <span class="mono">${esc(l.legacy_code)}</span></div>`).join('')}
        <div class="hint" style="margin:7px 0 0;font-size:11px">Legacy codes are retained, never overwritten.
          Each CPSE keeps addressing the item by its own ERP code.</div>

        <div class="kicker">Normalized attributes <span class="prov">pipeline output</span></div>
        <div class="attrgrid">
          ${Object.entries(m.attrs).map(([k, val]) =>
            `<div class="k">${esc(TULYA.attrLabel(k))}</div><div class="v">${esc(TULYA.attrValue(k, val))}</div>`).join('')
            || '<div class="k" style="grid-column:1/3">No specification was recovered from these descriptions.</div>'}
        </div>
      </div>

      <div>
        <div class="kicker">Engineering validation</div>
        ${c ? evidenceTableHTML(c) : '<div class="hint">No candidate pair was shipped for this record.</div>'}

        <div class="kicker">Standards evidence
          <span class="prov ${m.family === 'PIP' ? '' : 'sim'}">${m.family === 'PIP' ? 'source-backed' : 'prototype'}</span></div>
        ${fam.nodes.map(n => `<button class="stdchip${n.verified ? ' verified' : ''}"
           onclick="openStandard('${m.family}','${esc(n.id)}')">${esc(n.id)}</button>`).join('')
           || '<span class="hint">None on file.</span>'}

        <div class="kicker">Match analysis</div>
        ${c ? `<div class="twrap"><table><thead><tr><th>Signal</th><th class="num">Result</th><th>Source</th></tr></thead>
          <tbody>${analysis.map(([k, val, prov]) =>
            `<tr><td>${k}</td><td class="num mono">${esc(val)}</td>
              <td><span class="prov">${prov}</span></td></tr>`).join('')}</tbody></table></div>`
          : '<div class="hint">—</div>'}

        <div class="kicker">Decision</div>
        <div class="verdict ${v.key === 'CONFLICT' ? 'stop' : (v.key === 'IDENTICAL' || v.key === 'EQUIVALENT' ? 'merge' : 'hold')}">
          <b>${TULYA.VERDICTS[v.key].label} · ${TULYA.VERDICTS[v.key].next}</b>${esc(v.reason)}.
        </div>
        ${c && !approved ? `<div class="actbar">
          ${v.key === 'CONFLICT'
            ? '<span class="sig sig-unres">MERGE BLOCKED · HARD SPECIFICATION CONFLICT</span>'
            : `<button class="btn approve small" onclick="decide(${c.a},${c.b},'approve');renderPassport()">Approve</button>
               <button class="btn reject small" onclick="decide(${c.a},${c.b},'reject');renderPassport()">Reject</button>
               <button class="btn ghost small" onclick="conditionalHold(${c.a},${c.b})">Conditional</button>
               <button class="btn ghost small" onclick="requestVerification(${c.a},${c.b})">Request verification</button>`}
        </div>` : ''}
        ${approved ? `<div class="chain">
          <div class="c-step"><span class="m">✓</span><span><b>${esc(m.cnmc)}</b> issued</span></div>
          <div class="c-step"><span class="m">✓</span><span>Legacy mapping preserved — ${m.legacy_identities.map(l => esc(l.cpse) + ' ' + esc(l.legacy_code)).join(', ')}</span></div>
          <div class="c-step"><span class="m">✓</span><span>Cross-CPSE visibility enabled across ${esc(m.cpses.join(', '))}</span></div>
          <div class="c-step"><span class="m">✓</span><span>Demand aggregation enabled <span class="prov sim">simulated</span></span></div>
          <div class="c-step"><span class="m">✓</span><span>Audit entry created</span></div>
        </div>` : ''}

        <div class="actbar">
          <button class="jump" onclick="gotoProcurement('${m.id}')">Procurement</button>
          <button class="jump" onclick="gotoSimulator('${m.id}')">Simulate impact</button>
          <button class="jump" onclick="gotoCollab('${m.id}')">Collaboration case</button>
          <button class="jump" onclick="switchPanel('audit')">Audit log</button>
        </div>
      </div>
    </div></div>`;
}

function conditionalHold(a, b) {
  STATE.audit.unshift({ ts: Date.now() / 1000, action: 'conditional', record_a: a, record_b: b,
    steward: steward(), score: (ITEM_BY_KEY[pkey(a, b)] || {}).score || null,
    before: 'proposed', after: 'held as conditional equivalence',
    detail: 'engineering review required before mapping' });
  saveState(); toast('Marked conditional — routed to engineering review'); renderAll();
}
function requestVerification(a, b) {
  STATE.audit.unshift({ ts: Date.now() / 1000, action: 'verify', record_a: a, record_b: b,
    steward: steward(), score: (ITEM_BY_KEY[pkey(a, b)] || {}).score || null,
    before: 'proposed', after: 'standards verification requested',
    detail: 'verification of the standards cross-reference against the standard texts' });
  saveState(); toast('Standards verification requested'); renderAll();
}

/* ===========================================================================
   STANDARDS KNOWLEDGE GRAPH
   =========================================================================== */
let KG_FAMILY = 'PIP', KG_NODE = null;
function openStandard(fam, id) { KG_FAMILY = fam; KG_NODE = id; switchPanel('standards'); renderStandards(); }
function setKgFamily(f) { KG_FAMILY = f; KG_NODE = null; renderStandards(); }
function selectStandard(id) { KG_NODE = id; renderStandards(); }

const RELCLS = { EQUIVALENT: 'rel-equivalent', SUPERSET: 'rel-superset', SUBSTITUTE: 'rel-substitute',
                 CONFLICT: 'rel-conflict', 'REQUIRES VERIFICATION': 'rel-requires' };

function renderStandards() {
  const set = TULYA.STANDARDS[KG_FAMILY];
  el('kgFamilies').innerHTML = Object.keys(TULYA.STANDARDS).map(f =>
    `<button class="${f === KG_FAMILY ? 'on' : ''}" onclick="setKgFamily('${f}')">${esc(TULYA.FAMILY_NAME[f])}</button>`).join('');

  const root = set.nodes[0], others = set.nodes.slice(1);
  el('kgTree').innerHTML = `
    <button class="kg-root" onclick="selectStandard('${esc(root.id)}')">${esc(root.id)}</button>
    <div class="kg-branch">
      ${others.map(n => {
        const e = set.edges.find(x => (x.a === root.id && x.b === n.id) || (x.b === root.id && x.a === n.id));
        const rel = e ? e.rel : 'RELATED', st = e ? e.state : 'REQUIRES REVIEW';
        return `<div class="kg-edge"><span class="stem"></span>
          <span class="rel ${RELCLS[rel] || 'rel-requires'}">${rel}</span>
          <button class="kg-node ${KG_NODE === n.id ? 'on' : ''}" onclick="selectStandard('${esc(n.id)}')">${esc(n.id)}</button>
          <span class="state-chip ${st === 'SCOPED' ? 'state-scoped' : 'state-review'}">${st}</span></div>`;
      }).join('')}
    </div>
    <div class="hint" style="margin-top:16px;font-size:11.5px">Relationship types: EQUIVALENT · SUPERSET ·
      SUBSTITUTE · CONFLICT · REQUIRES VERIFICATION. No edge is drawn as unconditional.</div>
    <div class="serieskey">
      <span><span class="state-chip state-verified">VERIFIED</span> stated in the TULYA reference set</span>
      <span><span class="state-chip state-scoped">SCOPED</span> holds within a stated range</span>
      <span><span class="state-chip state-review">REQUIRES REVIEW</span> prototype, unverified</span>
    </div>`;

  const nodeId = KG_NODE || root.id;
  const n = set.nodes.find(x => x.id === nodeId) || root;
  const edges = set.edges.filter(e => e.a === nodeId || e.b === nodeId);
  const usedBy = TULYA.materials.filter(m => m.family === KG_FAMILY);

  el('kgPanel').innerHTML = `
    <div style="display:flex;align-items:center;gap:9px;flex-wrap:wrap;padding-bottom:11px;
                border-bottom:1px solid var(--line);margin-bottom:12px">
      <span class="mono" style="font-size:14px;font-weight:600;color:var(--n-900)">${esc(n.id)}</span>
      <span class="state-chip ${n.verified ? 'state-verified' : 'state-review'}">${n.verified ? 'VERIFIED' : 'PROTOTYPE — REQUIRES REVIEW'}</span>
    </div>
    <dl>
      <dt>Issuing body</dt><dd>${esc(n.body)}</dd>
      <dt>Scope</dt><dd>${esc(n.scope)}</dd>
      <dt>Relevant attributes</dt>
      <dd class="mono" style="font-size:11.5px">${[...new Set(usedBy.flatMap(m => Object.keys(m.attrs)))]
          .map(k => esc(TULYA.attrLabel(k))).join(' · ') || 'none recovered'}</dd>
      <dt>Relationships</dt>
      <dd>${edges.length ? edges.map(e => {
        const other = e.a === nodeId ? e.b : e.a;
        return `<div style="margin:6px 0"><span class="rel ${RELCLS[e.rel] || 'rel-requires'}">${e.rel}</span>
          <span class="mono" style="font-size:11.5px">${esc(other)}</span>
          <span class="state-chip ${e.state === 'SCOPED' ? 'state-scoped' : 'state-review'}">${e.state}</span>
          <div style="font-size:11.5px;color:var(--n-500);margin-top:3px">${esc(e.evidence)}</div></div>`;
      }).join('') : 'No relationship on file.'}</dd>
      <dt>Verification state</dt>
      <dd>${n.verified
        ? 'Source-backed. The cross-reference appears in the TULYA reference set and is scoped to the stated range — not a blanket equivalence.'
        : 'Prototype relationship. Shipped so the graph is walkable; not verified against the standard texts, and treated as REQUIRES VERIFICATION.'}</dd>
      <dt>Evidence reference</dt>
      <dd style="font-size:11.5px">${n.note ? esc(n.note) + '<br>' : ''}${n.verified
        ? 'TULYA reference set — standards section (BIS / BSI / ASTM / JIS designations).'
        : 'No published cross-reference cited. Steward action: request standards verification.'}</dd>
      <dt>Materials using this family</dt>
      <dd>${usedBy.length} identit${usedBy.length === 1 ? 'y' : 'ies'} ·
        ${usedBy.reduce((s, m) => s + m.records.length, 0)} source records
        ${usedBy.length ? `<br><button class="jump" style="margin-top:5px" onclick="openPassport('${usedBy[0].id}')">Open a material passport</button>` : ''}</dd>
    </dl>`;
}

/* ===========================================================================
   ANALYTICS
   =========================================================================== */
const STATUS_COLOR = { IDENTICAL: '#1F6B4A', EQUIVALENT: '#4E9873', CONDITIONAL: '#B98B34',
                       DIFFERENT: '#B9C3CC', CONFLICT: '#A3392C', UNRESOLVED: '#8C99A5' };
const SERIES_COLOR = { records: '#12283F', matched: '#1F6FB2', duplicates: '#B98B34',
                       reviews: '#A3392C', harmonised: '#1F6B4A' };

function hbar(label, value, max, cls, display) {
  const w = max ? Math.max(1, (value / max) * 100) : 1;
  return `<div class="hbar ${cls || ''}"><span class="lbl" title="${esc(label)}">${esc(label)}</span>
    <span class="track"><i style="width:${w.toFixed(1)}%"></i></span>
    <span class="num">${display != null ? display : qty(value)}</span></div>`;
}

function renderAnalytics() {
  const A = TULYA.analytics(STATE.reviews), t = A.totals;

  el('anKpis').style.gridTemplateColumns = 'repeat(5,1fr)';
  el('anKpis').innerHTML = [
    ['Material identities', qty(t.materials), 'after harmonisation', 'passport'],
    ['Harmonized', qty(t.harmonised), 'identical or equivalent', null],
    ['Pending review', qty(t.pending), 'conditional equivalence', 'collab'],
    ['Conflicts', qty(t.conflicts), 'merge blocked by veto', 'vetoed'],
    ['Cross-CPSE', qty(t.cross_cpse), 'identities in 2+ CPSEs', 'procurement']
  ].map(([k, v, s, go]) => go
    ? `<button onclick="switchPanel('${go}')"><span class="k">${k}</span><span class="v">${v}</span><span class="s">${s}</span></button>`
    : `<div><span class="k">${k}</span><span class="v">${v}</span><span class="s">${s}</span></div>`).join('');

  /* 1 — harmonisation overview, the large chart */
  const stTotal = Object.values(A.byStatus).reduce((s, x) => s + x, 0) || 1;
  el('anStatus').innerHTML = `
    <h4>Material harmonization overview</h4>
    <div class="cap">Governed verdict across every derived material identity. Derived from pipeline output.</div>
    <div class="body">
      <div class="stackbar">${Object.entries(A.byStatus).filter(([, n]) => n).map(([k, n]) =>
        `<i style="width:${(n / stTotal * 100).toFixed(2)}%;background:${STATUS_COLOR[k]}" title="${k}: ${n}"></i>`).join('')}</div>
      ${Object.entries(A.byStatus).map(([k, n]) =>
        `<div class="hbar wide"><span class="lbl">${verdictBadge(k)}</span>
          <span class="track"><i style="width:${(n / stTotal * 100).toFixed(1)}%;background:${STATUS_COLOR[k]}"></i></span>
          <span class="num">${qty(n)}</span></div>`).join('')}
    </div>`;

  /* 2 — CPSE distribution */
  const maxRec = Math.max(1, ...A.byCpse.flatMap(c => [c.records, c.matched, c.duplicates, c.reviews, c.harmonised]));
  el('anCpse').innerHTML = `
    <h4>CPSE distribution</h4>
    <div class="cap">Records, matched, duplicates, open reviews and harmonised records per CPSE.</div>
    <div class="body">
      ${A.byCpse.map(c => `<div class="grouped">
        <div class="lbl">${esc(c.cpse)}</div>
        <div class="series">${['records', 'matched', 'duplicates', 'reviews', 'harmonised'].map(k =>
          `<div class="srow"><span class="t"><i style="width:${(c[k] / maxRec * 100).toFixed(1)}%;background:${SERIES_COLOR[k]}"></i></span>
            <span class="n">${qty(c[k])}</span></div>`).join('')}</div></div>`).join('')}
      <div class="serieskey">${Object.entries(SERIES_COLOR).map(([k, v]) =>
        `<span><i style="background:${v}"></i>${k}</span>`).join('')}</div>
    </div>`;

  /* 3 — material category distribution */
  const maxFam = Math.max(...A.byFamily.map(f => f.records), 1);
  el('anCategory').innerHTML = `
    <h4>Material category distribution</h4>
    <div class="cap">Source records by material family; conflicts shown alongside.</div>
    <div class="body">${A.byFamily.map(f => hbar(f.name, f.records, maxFam, f.conflicts ? 'amber' : '',
      qty(f.records) + (f.conflicts ? ' · ' + f.conflicts + '✕' : ''))).join('')}</div>`;

  /* 4 — review status */
  const maxBand = Math.max(...Object.values(A.bands), 1);
  el('anBands').innerHTML = `
    <h4>Review status</h4>
    <div class="cap">Steward priority bands across the shipped cases. Pipeline priority ranking.</div>
    <div class="body">
      ${[['Critical', A.bands.CRITICAL, 'bad'], ['High', A.bands.HIGH, 'amber'],
         ['Medium', A.bands.MEDIUM, ''], ['Low', A.bands.LOW, 'dim']]
        .map(([l, n, c]) => hbar(l, n, maxBand, c)).join('')}
      <div class="actbar" style="margin-top:10px">
        <button class="jump" onclick="switchPanel('queue')">Open the review queue</button></div>
    </div>`;

  /* 5 — cross-CPSE opportunities, as a table */
  el('anOpportunities').innerHTML = crossTable(A.aggregation.slice(0, 10), 'an');
}

/* ===========================================================================
   COLLABORATION
   =========================================================================== */
let COLLAB_ID = null, COLLAB_STAGE = 'ALL';

function gotoCollab(matId) {
  const m = TULYA.byId[matId], c = m ? bestCaseFor(m) : null;
  if (c) { COLLAB_ID = pkey(c.a, c.b); COLLAB_STAGE = 'ALL'; }
  switchPanel('collab'); renderCollab();
}
function openCase(a, b) { COLLAB_ID = pkey(a, b); COLLAB_STAGE = 'ALL'; switchPanel('collab'); renderCollab(); }
function setCollabStage(s) { COLLAB_STAGE = s; renderCollab(); }

function collabCases() {
  const seen = {};
  return TULYA.cases.filter(it => { const k = pkey(it.a, it.b); if (seen[k]) return false; seen[k] = 1; return true; })
    .map(TULYA.caseOf)
    .filter(c => COLLAB_STAGE === 'ALL' || TULYA.STAGES[c.stage] === COLLAB_STAGE);
}

function renderCollab() {
  const cases = collabCases();
  el('collabStages').innerHTML = ['ALL'].concat(TULYA.STAGES).map(s =>
    `<button class="${COLLAB_STAGE === s ? 'on' : ''}" onclick="setCollabStage('${s}')">${s === 'ALL' ? 'All' : s}</button>`).join('');
  if (el('collabCount')) el('collabCount').textContent = qty(cases.length);
  el('collabListCount').innerHTML = showing(Math.min(50, cases.length), cases.length, 'cases');

  el('collabList').innerHTML = cases.slice(0, 50).map(c => {
    const on = pkey(c.pair.a, c.pair.b) === COLLAB_ID;
    return `<button class="r${on ? ' on' : ''}" onclick="openCase(${c.pair.a},${c.pair.b})">
      <div class="d">${esc(c.pair.record_a.description)}</div>
      <div class="m"><span>${esc(c.case_id)}</span><span>${esc(c.stage_name)}</span></div>
      <div style="margin-top:4px">${verdictBadge(c.verdict.key)}</div>
    </button>`;
  }).join('') || '<div class="empty">No case at this stage.</div>';

  const chosen = cases.find(c => pkey(c.pair.a, c.pair.b) === COLLAB_ID) || cases[0];
  if (!chosen) { el('collabDetail').innerHTML = '<div class="empty">No case selected.</div>'; return; }
  COLLAB_ID = pkey(chosen.pair.a, chosen.pair.b);
  el('collabDetail').innerHTML = caseHTML(chosen);
}

function caseHTML(c) {
  const it = c.pair, m = c.material;
  const reviewed = STATE.reviews[pkey(it.a, it.b)];
  const st = TULYA.standardsEvidence(it);
  return `<div class="panel-box">
    <div class="ph"><span>${esc(c.case_id)}</span>
      <span class="side">${verdictBadge(c.verdict.key, true)}</span></div>
    <div class="pb">
      <div style="font-size:14.5px;font-weight:600;color:var(--n-900)">${esc(it.record_a.description)}</div>
      <div class="wf-rail">${TULYA.STAGES.map((s, i) =>
        `<span class="n ${i < c.stage ? 'done' : (i === c.stage ? 'now' : '')}">${s}</span>`).join('')}</div>

      <div class="twrap" style="margin-top:12px"><table><tbody>
        <tr><td style="width:180px;color:var(--n-500)">Material</td><td>${esc(it.record_a.description)}</td></tr>
        <tr><td style="color:var(--n-500)">Legacy code · CPSE</td>
            <td class="mono">${esc(it.record_a.legacy_code)} (${esc(it.record_a.cpse)}) · ${esc(it.record_b.legacy_code)} (${esc(it.record_b.cpse)})</td></tr>
        <tr><td style="color:var(--n-500)">Candidate match</td><td>${esc(it.record_b.description)}</td></tr>
        <tr><td style="color:var(--n-500)">Confidence</td><td class="mono">${(it.score * 100).toFixed(1)}%</td></tr>
        <tr><td style="color:var(--n-500)">Attributes</td><td class="mono" style="font-size:11.5px">${
          (it.explain.attributes || []).map(a => esc(TULYA.attrLabel(a.key)) + ' ' +
            (a.verdict === 'MATCH' ? '✓' : a.verdict === 'MISMATCH' ? '✕' : '?')).join(' · ') || 'none readable'}</td></tr>
        <tr><td style="color:var(--n-500)">Standards evidence</td><td class="mono" style="font-size:11.5px">${
          st ? esc(st.a) + ' vs ' + esc(st.b) + ' — ' + st.rel : 'none on file'}
          ${st ? `<span class="state-chip ${st.verified ? 'state-verified' : 'state-review'}">${st.verified ? 'VERIFIED' : 'REQUIRES REVIEW'}</span>` : ''}</td></tr>
        <tr><td style="color:var(--n-500)">Conflict status</td><td>${c.verdict.key === 'CONFLICT'
          ? '<span class="sig sig-unres">HARD CONFLICT · MERGE BLOCKED</span>' : '<span class="sig sig-stock">NONE DETECTED</span>'}</td></tr>
        <tr><td style="color:var(--n-500)">Procurement status</td><td>${esc(c.procurement)} <span class="prov sim">simulated</span></td></tr>
        <tr><td style="color:var(--n-500)">Decision</td><td>${reviewed
          ? '<span class="pill ' + esc(reviewed.action) + '">' + esc(reviewed.action) + '</span> by ' + esc(reviewed.steward)
          : '<span class="pill review">PENDING</span>'}</td></tr>
      </tbody></table></div>

      <div class="assign">
        <div><label>Assigned steward</label>
          <select onchange="assignRole(${it.a},${it.b},'steward',this.value)">
            ${['R. Nair', 'A. Deshmukh', 'P. Iyer', 'S. Banerjee', 'M. Qureshi'].map(s =>
              `<option ${s === c.steward ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
        <div><label>Assigned engineer</label>
          <select onchange="assignRole(${it.a},${it.b},'engineer',this.value)">
            <option ${!c.engineer ? 'selected' : ''}>— not assigned —</option>
            ${['V. Rao (Static)', 'K. Menon (Rotating)', 'T. Ghosh (Piping)', 'D. Shah (Electrical)'].map(s =>
              `<option ${s === c.engineer ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
      </div>

      <div class="actbar">
        ${c.verdict.key === 'CONFLICT' ? '' :
          `<button class="btn approve small" onclick="decide(${it.a},${it.b},'approve');renderCollab()">Approve</button>`}
        <button class="btn ghost small" onclick="caseAction(${it.a},${it.b},'engineering')">Request review</button>
        <button class="btn ghost small" onclick="requestVerification(${it.a},${it.b})">Standards verification</button>
        ${c.verdict.key === 'CONFLICT' ? '' :
          `<button class="btn ghost small" onclick="conditionalHold(${it.a},${it.b})">Conditional</button>`}
        <button class="btn ghost small" onclick="caseAction(${it.a},${it.b},'comment')">Comment</button>
        <button class="btn ghost small" onclick="caseAction(${it.a},${it.b},'escalate')">Escalate</button>
        ${c.verdict.key === 'CONFLICT' ? '' :
          `<button class="btn reject small" onclick="decide(${it.a},${it.b},'reject');renderCollab()">Reject</button>`}
      </div>

      <div class="case-grid" style="margin-top:18px">
        <div>
          <div class="kicker">Engineering evidence</div>
          ${evidenceTableHTML(it)}
        </div>
        <div>
          <div class="kicker">Decision timeline</div>
          <div class="tline">${TULYA.timelineOf(c).map(s =>
            `<div class="tl-i ${s.state}"><div class="h">${esc(s.head)}</div>
              <div class="d">${esc(s.detail)}</div></div>`).join('')}</div>
          <div class="kicker">Activity</div>
          <div class="feed">${TULYA.activityOf(c).map(f =>
            `<div class="f"><span class="t">${f.at}</span><span>${esc(f.text)}</span></div>`).join('')}</div>
          ${m ? `<div class="actbar">
            <button class="jump" onclick="openPassport('${m.id}')">Passport</button>
            <button class="jump" onclick="gotoProcurement('${m.id}')">Procurement</button>
            <button class="jump" onclick="gotoSimulator('${m.id}')">Simulate impact</button></div>` : ''}
        </div>
      </div>
    </div></div>`;
}

function assignRole(a, b, role, who) {
  STATE.audit.unshift({ ts: Date.now() / 1000, action: 'assign', record_a: a, record_b: b,
    steward: steward(), score: null, before: null, after: null, detail: role + ' assigned: ' + who });
  saveState(); toast(role === 'steward' ? 'Steward assigned' : 'Engineer assigned'); renderAudit();
}
function caseAction(a, b, kind) {
  const labels = { comment: 'Comment added', engineering: 'Engineering review requested',
                   escalate: 'Escalated to final governance' };
  let note = '';
  if (kind === 'comment') { note = prompt('Comment on this case:') || ''; if (!note) return; }
  STATE.audit.unshift({ ts: Date.now() / 1000,
    action: kind === 'comment' ? 'comment' : (kind === 'escalate' ? 'escalate' : 'engineering'),
    record_a: a, record_b: b, steward: steward(), score: null, before: null, after: null,
    detail: note || labels[kind] });
  saveState(); toast(labels[kind]); renderCollab(); renderAudit();
}

/* ===========================================================================
   CROSS-CPSE IMPACT SIMULATOR
   =========================================================================== */
let SIM_MAT = null, SIM_CPSES = null, SIM_SCENARIO = 0, SIM_REQUIRED = null;

function gotoSimulator(matId) { SIM_MAT = matId; SIM_CPSES = null; SIM_REQUIRED = null; switchPanel('simulator'); renderSimulator(); }
function setSimMat(id) { SIM_MAT = id; SIM_CPSES = null; SIM_REQUIRED = null; renderSimulator(); }
function toggleSimCpse(c) {
  SIM_CPSES = SIM_CPSES || [];
  SIM_CPSES = SIM_CPSES.includes(c) ? SIM_CPSES.filter(x => x !== c) : SIM_CPSES.concat(c);
  renderSimulator();
}
function setScenario(i) { SIM_SCENARIO = i; renderSimulator(); }
function setRequired(v) { SIM_REQUIRED = Math.max(0, +v || 0); renderSimulator(); }

function renderSimulator() {
  const candidates = TULYA.materials.filter(m => m.cross_cpse).slice(0, 40);
  if (!SIM_MAT || !TULYA.byId[SIM_MAT]) SIM_MAT = (candidates[0] || TULYA.materials[0] || {}).id;
  const m = TULYA.byId[SIM_MAT];
  if (!m) { el('simBody').innerHTML = '<div class="empty">No material available.</div>'; return; }
  if (!SIM_CPSES) SIM_CPSES = m.cpses.slice();

  el('simPicker').innerHTML = candidates.map(x =>
    `<option value="${x.id}" ${x.id === SIM_MAT ? 'selected' : ''}>${esc(x.description.slice(0, 54))}</option>`).join('');

  const scenarios = [['Current', 1], ['+10%', 1.1], ['+25%', 1.25], ['+50%', 1.5]];
  const baseReq = SIM_REQUIRED != null ? SIM_REQUIRED : (m.demand ? m.demand.qty : Math.round(m.stock_total * 0.55));
  const required = Math.round(baseReq * scenarios[SIM_SCENARIO][1]);
  const participating = m.stock.filter(s => SIM_CPSES.includes(s.cpse));
  const combined = participating.reduce((s, x) => s + x.qty, 0);
  const coverage = required ? Math.min(1, combined / required) : 0;
  const surplus = Math.max(0, combined - required);
  const shortfall = Math.max(0, required - combined);
  const legacyConsolidated = m.legacy_identities.filter(l => SIM_CPSES.includes(l.cpse)).length;
  const simMax = Math.max(20, Math.round(Math.max(m.stock_total, baseReq) * 2));
  const simStep = Math.max(1, Math.round(simMax / 200));
  const perCpse = {};
  m.stock.forEach(s => { perCpse[s.cpse] = (perCpse[s.cpse] || 0) + s.qty; });

  el('simControls').innerHTML = `
    <div class="sim-row"><label>CPSE participation</label>
      <div class="cpse-toggles">${m.cpses.map(c =>
        `<button class="${SIM_CPSES.includes(c) ? 'on' : ''}" onclick="toggleSimCpse('${c}')">
          <span class="bx">${SIM_CPSES.includes(c) ? '■' : '□'}</span>${esc(c)}
          <span class="q">${qty(perCpse[c])}</span></button>`).join('')}</div></div>
    <div class="sim-row"><label>Demand scenario</label>
      <div class="scenario">${scenarios.map(([l], i) =>
        `<button class="${SIM_SCENARIO === i ? 'on' : ''}" onclick="setScenario(${i})">${l}</button>`).join('')}</div></div>
    <div class="sim-row"><label>Required quantity</label>
      <div class="reqrow">
        <input type="range" min="0" max="${simMax}" step="${simStep}"
               value="${Math.min(baseReq, simMax)}" oninput="setRequired(this.value)">
        <span class="q">${qty(required)} ${esc(m.unit)}</span>
      </div></div>`;

  el('simBody').innerHTML = `
    <div class="ba">
      <div class="side">
        <h5>Before — separate identities</h5>
        ${m.stock.map(s => `<div class="silo">
          <span>${esc(s.cpse)} <span class="mono" style="color:var(--n-400)">${esc(s.legacy_code)}</span></span>
          <span class="q">${qty(s.qty)}</span></div>`).join('')}
        <div class="hint" style="margin:9px 0 0;font-size:11px">${m.legacy_identities.length} separate legacy
          codes. No stock position here is visible to the others.</div>
      </div>
      <div class="mid">→</div>
      <div class="side after">
        <h5>After proposed harmonisation</h5>
        <div class="mono" style="font-size:11.5px;color:var(--n-900);font-weight:600;word-break:break-all">${esc(m.cnmc)}</div>
        <div class="hint" style="margin:3px 0 10px;font-size:10.5px">common material identity</div>
        <div style="font-size:9.5px;color:var(--n-500);text-transform:uppercase;letter-spacing:.7px;font-weight:600">Visible combined stock</div>
        <div class="bigqty">${qty(combined)} <span style="font-size:13px;font-weight:500;color:var(--n-500)">${esc(m.unit)}</span></div>
        <div class="hint" style="margin:6px 0 0;font-size:11px">${SIM_CPSES.length} participating
          CPSE${SIM_CPSES.length === 1 ? '' : 's'} · ${legacyConsolidated} legacy identities consolidated</div>
      </div>
    </div>

    <div class="chart" style="margin-top:14px">
      <h4>Impact results</h4>
      <div class="body" style="padding:0">
        <div class="simout">
          <div class="o"><div class="v">${qty(required)}</div><div class="k">Current demand</div></div>
          <div class="o good"><div class="v">${qty(combined)}</div><div class="k">Available stock</div></div>
          <div class="o ${coverage >= 0.6 ? 'good' : 'amber'}"><div class="v">${(coverage * 100).toFixed(0)}%</div><div class="k">Projected coverage</div></div>
          <div class="o ${shortfall ? 'amber' : 'good'}"><div class="v">${qty(shortfall)}</div><div class="k">Procurement requirement</div></div>
          <div class="o"><div class="v">${qty(surplus)}</div><div class="k">Potential surplus</div></div>
          <div class="o"><div class="v">${SIM_CPSES.length > 1 ? 'Yes' : 'No'}</div><div class="k">Aggregation opportunity</div></div>
          <div class="o"><div class="v">${legacyConsolidated}</div><div class="k">Legacy codes consolidated</div></div>
          <div class="o"><div class="v">${m.cpses.length}</div><div class="k">CPSEs in identity</div></div>
        </div>
        <div style="padding:13px 14px">
          <div style="font-size:10px;color:var(--n-500);text-transform:uppercase;letter-spacing:.6px;font-weight:600">
            Coverage of required quantity</div>
          <div class="covermeter"><i class="${coverage >= 1 ? '' : 'part'}" style="width:${(coverage * 100).toFixed(1)}%"></i></div>
        </div>
      </div>
    </div>

    <div class="chart" style="margin-top:14px">
      <h4>Stock contribution by CPSE</h4>
      <div class="cap">Only selected CPSEs contribute to the combined figure.</div>
      <div class="body">
        ${m.stock.map(s => {
          const on = SIM_CPSES.includes(s.cpse);
          const max = Math.max(...m.stock.map(x => x.qty), 1);
          return `<div class="hbar ${on ? '' : 'dim'}">
            <span class="lbl">${on ? '■' : '□'} ${esc(s.cpse)} · ${esc(s.plant || '')}</span>
            <span class="track"><i style="width:${(s.qty / max * 100).toFixed(1)}%"></i></span>
            <span class="num">${qty(s.qty)}</span></div>`;
        }).join('')}
      </div>
    </div>

    <div class="actbar">
      <button class="jump" onclick="openPassport('${m.id}')">Material passport</button>
      <button class="jump" onclick="gotoProcurement('${m.id}')">Procurement intelligence</button>
      <button class="jump" onclick="gotoCollab('${m.id}')">Request review</button>
    </div>`;
}

/* ===========================================================================
   PROCUREMENT INTELLIGENCE
   =========================================================================== */
const SIG_SHORT = { 'CROSS-CPSE STOCK FOUND': 'STOCK FOUND',
  'DEMAND AGGREGATION CANDIDATE': 'AGGREGATION', 'OPPORTUNITY DETECTED': 'OPPORTUNITY',
  'NO CROSS-CPSE STOCK': 'NO STOCK', 'UNRESOLVED CASE': 'UNRESOLVED' };
const SIGCLS = { 'CROSS-CPSE STOCK FOUND': 'sig-stock', 'DEMAND AGGREGATION CANDIDATE': 'sig-agg',
                 'OPPORTUNITY DETECTED': 'sig-opp', 'NO CROSS-CPSE STOCK': 'sig-none',
                 'UNRESOLVED CASE': 'sig-unres' };
const PROC = { cpse: 'ALL', family: 'ALL', signal: 'ALL', stock: 'ALL', review: 'ALL',
               q: '', sort: 'coverage', dir: -1, page: 0, size: 25, focus: null };

function gotoProcurement(matId) {
  Object.assign(PROC, { cpse: 'ALL', family: 'ALL', signal: 'ALL', stock: 'ALL', review: 'ALL',
                        q: '', page: 0, focus: matId });
  switchPanel('procurement'); renderProcurement();
}
function setProc(k, v) { PROC[k] = v; PROC.page = 0; PROC.focus = null; renderProcurement(); }
function clearProc() {
  Object.assign(PROC, { cpse: 'ALL', family: 'ALL', signal: 'ALL', stock: 'ALL', review: 'ALL',
                        q: '', page: 0, focus: null });
  renderProcurement();
}
function sortProc(k) { if (PROC.sort === k) PROC.dir *= -1; else { PROC.sort = k; PROC.dir = -1; } renderProcurement(); }
function pageProc(d) { PROC.page = Math.max(0, PROC.page + d); renderProcurement(); }

function procFiltered() {
  let rows = TULYA.procurementRows();
  if (PROC.focus) return rows.filter(r => r.material.id === PROC.focus);
  if (PROC.cpse !== 'ALL') rows = rows.filter(r => r.material.cpses.includes(PROC.cpse));
  if (PROC.family !== 'ALL') rows = rows.filter(r => r.material.family === PROC.family);
  if (PROC.signal !== 'ALL') rows = rows.filter(r => r.signal === PROC.signal);
  if (PROC.stock === 'AVAILABLE') rows = rows.filter(r => r.available > 0);
  if (PROC.stock === 'NONE') rows = rows.filter(r => !r.available);
  if (PROC.review !== 'ALL') rows = rows.filter(r => r.review_status === PROC.review);
  if (PROC.q) {
    const q = PROC.q.toLowerCase();
    rows = rows.filter(r => (r.material.description + ' ' + r.material.cnmc + ' ' +
      r.material.cpses.join(' ')).toLowerCase().includes(q));
  }
  const key = { coverage: r => r.coverage, required: r => r.required, available: r => r.available,
                material: r => r.material.description.toLowerCase() }[PROC.sort] || (r => r.coverage);
  return rows.sort((a, b) => { const x = key(a), y = key(b);
    return (x < y ? -1 : x > y ? 1 : 0) * PROC.dir; });
}

function renderProcurement() {
  const all = TULYA.procurementRows();
  const counts = {
    open: all.length,
    stock: all.filter(r => r.signal === 'CROSS-CPSE STOCK FOUND').length,
    dup: all.filter(r => r.material.cross_cpse && r.coverage > 0).length,
    agg: all.filter(r => r.signal === 'CROSS-CPSE STOCK FOUND' || r.signal === 'DEMAND AGGREGATION CANDIDATE').length,
    unres: all.filter(r => r.signal === 'UNRESOLVED CASE' || r.review_status === 'UNRESOLVED').length
  };
  if (el('procTotal')) el('procTotal').textContent = qty(counts.open);
  el('procKpis').style.gridTemplateColumns = 'repeat(5,1fr)';
  el('procKpis').innerHTML = [
    ['Open material demand', counts.open, () => clearProc()],
    ['Cross-CPSE stock found', counts.stock, () => setProc('signal', 'CROSS-CPSE STOCK FOUND')],
    ['Duplicate procurement candidates', counts.dup, () => setProc('stock', 'AVAILABLE')],
    ['Demand aggregation opportunities', counts.agg, () => setProc('signal', 'DEMAND AGGREGATION CANDIDATE')],
    ['Unresolved procurement cases', counts.unres, () => setProc('review', 'UNRESOLVED')]
  ].map(([k, v], i) => `<button onclick="PROC_KPI[${i}]()"><span class="k">${k}</span>
      <span class="v">${qty(v)}</span><span class="s">Filter</span></button>`).join('');
  window.PROC_KPI = [() => clearProc(), () => setProc('signal', 'CROSS-CPSE STOCK FOUND'),
    () => setProc('stock', 'AVAILABLE'), () => setProc('signal', 'DEMAND AGGREGATION CANDIDATE'),
    () => setProc('review', 'UNRESOLVED')];

  const cpses = [...new Set(all.flatMap(r => r.material.cpses))].sort();
  const fams = [...new Set(all.map(r => r.material.family))];
  const opt = (v, cur, label) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${label}</option>`;
  el('procFilters').innerHTML = `
    <div class="f"><label>CPSE</label><select onchange="setProc('cpse',this.value)">
      ${opt('ALL', PROC.cpse, 'All CPSEs')}${cpses.map(c => opt(c, PROC.cpse, c)).join('')}</select></div>
    <div class="f"><label>Material category</label><select onchange="setProc('family',this.value)">
      ${opt('ALL', PROC.family, 'All categories')}${fams.map(f => opt(f, PROC.family, TULYA.FAMILY_NAME[f])).join('')}</select></div>
    <div class="f"><label>Demand status</label><select onchange="setProc('signal',this.value)">
      ${opt('ALL', PROC.signal, 'All')}${Object.keys(SIGCLS).map(s => opt(s, PROC.signal, s)).join('')}</select></div>
    <div class="f"><label>Stock availability</label><select onchange="setProc('stock',this.value)">
      ${opt('ALL', PROC.stock, 'Any')}${opt('AVAILABLE', PROC.stock, 'Stock elsewhere')}${opt('NONE', PROC.stock, 'None found')}</select></div>
    <div class="f"><label>Review status</label><select onchange="setProc('review',this.value)">
      ${opt('ALL', PROC.review, 'All')}${Object.keys(TULYA.VERDICTS).map(k => opt(k, PROC.review, TULYA.VERDICTS[k].label)).join('')}</select></div>
    <div class="f" style="min-width:180px"><label>Search</label>
      <input value="${esc(PROC.q)}" placeholder="Material, CNMC, CPSE"
             oninput="PROC.q=this.value;PROC.page=0;PROC.focus=null;renderProcurement();document.querySelector('#procFilters input').focus()"></div>
    <div class="spacer"></div>
    <button class="btn ghost" onclick="clearProc()">Clear filters</button>
    <button class="btn ghost" onclick="exportProc()">Export CSV</button>`;

  const rows = procFiltered();
  const from = PROC.page * PROC.size, page = rows.slice(from, from + PROC.size);
  const arrow = k => PROC.sort === k ? `<span class="sort">${PROC.dir > 0 ? '▲' : '▼'}</span>` : '<span class="sort">▾</span>';
  const th = (k, label, num) => `<th${num ? ' class="num' : ' class="'}${PROC.sort === k ? ' on' : ''}" data-sort="${k}" onclick="sortProc('${k}')">${label}${arrow(k)}</th>`;

  el('procTable').innerHTML = !rows.length
    ? '<div class="empty">No procurement case matches these filters.</div>'
    : `<div class="twrap"><table>
      <thead><tr>
        ${th('material', 'Material')}<th>CNMC</th><th>Req. CPSE</th>
        ${th('required', 'Demand', 1)}${th('available', 'Stock avail.', 1)}<th>Stock CPSE</th>
        ${th('coverage', 'Coverage')}<th>Std.</th><th>Status</th><th>Action</th>
      </tr></thead><tbody>
      ${page.map(r => `<tr>
        <td>${esc(r.material.description)}<div class="site">${esc(r.material.category_label)}</div></td>
        <td class="mono cnmc" title="${esc(r.material.cnmc)}">${esc(r.material.cnmc)}</td>
        <td><b>${esc(r.requesting_cpse)}</b></td>
        <td class="num mono">${qty(r.required)}</td>
        <td class="num mono">${qty(r.available)}</td>
        <td>${r.best_source ? '<b>' + esc(r.best_source.cpse) + '</b><div class="site">' + esc(r.best_source.plant || '') + '</div>' : '—'}</td>
        <td><div class="cov-mini"><span class="t"><i class="${r.coverage >= 1 ? '' : 'part'}" style="width:${(r.coverage * 100).toFixed(0)}%"></i></span>
          <span class="mono">${(r.coverage * 100).toFixed(0)}%</span></div>
          <span class="sig ${SIGCLS[r.signal]}" style="margin-top:3px" title="${r.signal}">${SIG_SHORT[r.signal] || r.signal}</span></td>
        <td><span class="state-chip ${r.standards_status === 'VERIFIED CROSS-REFERENCE' ? 'state-verified' : 'state-review'}" title="${r.standards_status}">${r.standards_status === 'VERIFIED CROSS-REFERENCE' ? 'VERIFIED' : (r.standards_status === 'NONE ON FILE' ? 'NONE' : 'REVIEW')}</span></td>
        <td>${verdictBadge(r.review_status, false, true)}</td>
        <td><div class="rowacts">
          <button onclick="openPassport('${r.material.id}')">Material</button>
          <button onclick="gotoSimulator('${r.material.id}')">Simulate</button>
          <button onclick="gotoCollab('${r.material.id}')">Review</button>
        </div></td></tr>`).join('')}
      </tbody></table></div>
      <div class="tfoot">
        ${showing(Math.min(PROC.size, rows.length - from), rows.length, 'procurement cases')}
        <span class="pg">
          <button class="btn ghost small" ${from === 0 ? 'disabled' : ''} onclick="pageProc(-1)">Previous</button>
          <span style="padding:0 6px">Page ${PROC.page + 1} of ${Math.max(1, Math.ceil(rows.length / PROC.size))}</span>
          <button class="btn ghost small" ${from + PROC.size >= rows.length ? 'disabled' : ''} onclick="pageProc(1)">Next</button>
        </span>
      </div>`;
}

function exportProc() {
  const rows = procFiltered();
  const head = ['Material', 'CNMC', 'Requesting CPSE', 'Demand', 'Available stock', 'Stock CPSE',
                'Coverage %', 'Standards status', 'Review status', 'Signal'];
  const body = rows.map(r => [r.material.description, r.material.cnmc, r.requesting_cpse, r.required,
    r.available, r.best_source ? r.best_source.cpse : '', (r.coverage * 100).toFixed(0),
    r.standards_status, r.review_status, r.signal]);
  const csv = [head].concat(body).map(l => l.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  a.download = 'tulya_procurement_opportunities.csv';
  a.click(); URL.revokeObjectURL(a.href);
  toast(rows.length + ' rows exported — simulated quantities');
}

/* ===========================================================================
   panel dispatch
   =========================================================================== */
function renderTulyaPanels() {
  const safe = (n, f) => { try { f(); } catch (e) { console.error(n, e); } };
  safe('passport', renderPassport);
  safe('standards', renderStandards);
  safe('analytics', renderAnalytics);
  safe('collab', renderCollab);
  safe('simulator', renderSimulator);
  safe('procurement', renderProcurement);
}
